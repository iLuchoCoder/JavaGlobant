package com.example.demo.controller;

public class MyException extends RuntimeException {

}
