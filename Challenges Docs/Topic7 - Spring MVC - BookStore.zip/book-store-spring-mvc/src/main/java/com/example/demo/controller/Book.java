package com.example.demo.controller;

public record Book(int id, String title, double price) {

}
